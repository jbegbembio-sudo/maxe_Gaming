using UnityEngine;
using UnityEngine.UI;

public class FootballPrototype : MonoBehaviour
{
    void Start()
    {
        CreatePitch();
        CreatePlayers();
        CreateBall();
        CreateCamera();
        CreateUI();
    }

    void CreatePitch()
    {
        GameObject p = GameObject.CreatePrimitive(PrimitiveType.Cube);
        p.name = "Terrain";
        p.transform.position = Vector3.zero;
        p.transform.localScale = new Vector3(28, .2f, 18);

        Line(new Vector3(0,.12f,9), new Vector3(28,.05f,.08f));
        Line(new Vector3(0,.12f,-9), new Vector3(28,.05f,.08f));
        Line(new Vector3(-14,.12f,0), new Vector3(.08f,.05f,18));
        Line(new Vector3(14,.12f,0), new Vector3(.08f,.05f,18));
        Line(new Vector3(0,.12f,0), new Vector3(.08f,.05f,18));
    }

    void Line(Vector3 pos, Vector3 scale)
    {
        GameObject l = GameObject.CreatePrimitive(PrimitiveType.Cube);
        l.transform.position = pos;
        l.transform.localScale = scale;
    }

    void CreatePlayers()
    {
        Vector3[] positions = {
            new Vector3(-10,1,0), new Vector3(-6,1,5), new Vector3(-6,1,-5),
            new Vector3(-2,1,3), new Vector3(-2,1,-3), new Vector3(0,1,0),
            new Vector3(10,1,0), new Vector3(6,1,5), new Vector3(6,1,-5),
            new Vector3(2,1,3), new Vector3(2,1,-3), new Vector3(0,1,0)
        };

        for(int i=0;i<positions.Length;i++)
        {
            GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            player.name = i < 6 ? "Equipe A - Joueur "+i : "Equipe B - Joueur "+(i-6);
            player.transform.position = positions[i];
        }
    }

    void CreateBall()
    {
        GameObject ball = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        ball.name = "Ballon";
        ball.transform.position = new Vector3(0,.7f,0);
        ball.transform.localScale = Vector3.one*.7f;
        ball.AddComponent<Rigidbody>();
    }

    void CreateCamera()
    {
        GameObject cam = new GameObject("Camera Match");
        cam.AddComponent<Camera>();
        cam.transform.position = new Vector3(0,24,-22);
        cam.transform.rotation = Quaternion.Euler(55,0,0);
    }

    void CreateUI()
    {
        GameObject canvas = new GameObject("Interface");
        Canvas c = canvas.AddComponent<Canvas>();
        c.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.AddComponent<CanvasScaler>();
        canvas.AddComponent<GraphicRaycaster>();

        GameObject obj = new GameObject("Score");
        obj.transform.SetParent(canvas.transform);
        Text text = obj.AddComponent<Text>();
        text.text = "LU FOOTBALL LEGENDS     0 - 0";
        text.fontSize = 30;
        text.alignment = TextAnchor.UpperCenter;
        text.rectTransform.anchorMin = new Vector2(0,1);
        text.rectTransform.anchorMax = new Vector2(1,1);
        text.rectTransform.anchoredPosition = new Vector2(0,-35);
        text.rectTransform.sizeDelta = new Vector2(0,60);
    }
}
