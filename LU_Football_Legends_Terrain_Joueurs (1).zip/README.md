# LU Football Legends — Terrain + Joueurs
Prototype Unity de départ avec terrain, joueurs, ballon, caméra et interface de score.
Ouvre ce dossier dans Unity pour continuer le développement.
